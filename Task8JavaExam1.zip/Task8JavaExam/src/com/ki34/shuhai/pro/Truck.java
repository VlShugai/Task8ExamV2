package com.ki34.shuhai.pro;

import java.lang.reflect.Method;

@CarInter(carMass = 20000)
public class Truck extends Car {
    private int massOfTrailer;
    private int countOfWheel;

    public Truck(int massOfTrailer, int countOfWheel) {
        this.massOfTrailer = massOfTrailer;
        this.countOfWheel = countOfWheel;
    }

    public void showInformationAboutCar(){

        System.out.println( );
        System.out.println("mass of trailer: "+massOfTrailer);
        System.out.println("count of wheel: " + countOfWheel);
    }

}
