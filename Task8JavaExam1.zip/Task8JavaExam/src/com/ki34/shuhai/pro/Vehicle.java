package com.ki34.shuhai.pro;

public interface Vehicle {
    boolean ride();
}
