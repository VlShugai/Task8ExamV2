package com.ki34.shuhai.pro;

public class Main {

    public static void main(String[] args) {
        Truck truck = new Truck(12344,8);
        truck.startRide(truck.ride());
        truck.showInformationAboutCar();
truck.showCarMass();
    }
}
